<?php if($paginator->hasPages()): ?>
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled">
                    <span class="page-link text-dark">&laquo; Previous</span> <!-- Ubah warna teks menjadi hitam -->
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link text-dark" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">&laquo; Previous</a> <!-- Ubah warna teks menjadi hitam -->
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="page-item disabled"><span class="page-link text-dark"><?php echo e($element); ?></span></li> <!-- Ubah warna teks menjadi hitam -->
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="page-item active" aria-current="page">
                                <span class="page-link text-white bg-dark"><?php echo e($page); ?></span> <!-- Ubah warna teks menjadi putih dan latar belakang menjadi hitam -->
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a class="page-link text-dark" href="<?php echo e($url); ?>"><?php echo e($page); ?></a> <!-- Ubah warna teks menjadi hitam -->
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link text-dark" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Next &raquo;</a> <!-- Ubah warna teks menjadi hitam -->
                </li>
            <?php else: ?>
                <li class="page-item disabled">
                    <span class="page-link text-dark">Next &raquo;</span> <!-- Ubah warna teks menjadi hitam -->
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?><?php /**PATH C:\Vs Code\pibiti-2024\cashed\resources\views/vendor/pagination/bootstrap-5.blade.php ENDPATH**/ ?>