<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Order #'.e($order->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Order #'.e($order->id).'']); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="card mb-2">
                    <div class="card-body border-bottom">
                        <h5 class="mb-3">Terimaksih Sudah Melakukan Pembelian.</h5>
                        <div class="d-flex">
                            <div>Order ID:</div>
                            <div class="ms-auto"><?php echo e($order->id); ?></div>
                        </div>
                        <div class="d-flex">
                            <div>Admin:</div>
                            <div class="ms-auto"><?php echo e(auth()->user()->name); ?></div>
                        </div>

                        <div class="d-flex">
                            <div>Customer:</div>
                            <div class="ms-auto"><?php echo e($order->customer); ?></div>
                        </div>

                        <div class="d-flex">
                            <div>Date:</div>
                            <div class="ms-auto"><?php echo e($order->formatted_created_at); ?></div>
                        </div>
                    </div>

                    <div class="card-body border-bottom">
                        <div class="d-grid gap-2">
                            <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card">
                                    <div class="card-body">
                                        <div><?php echo e($detail->product->name); ?></div>

                                        <div class="d-flex">
                                            <div class="form-text">
                                                <?php echo e(number_format($detail->qty)); ?> x <?php echo e(number_format($detail->price)); ?> (Diskon: <?php echo e($detail->discount); ?>%)
                                            </div>
                                            <div class="ms-auto form-text">
                                                Rp<?php echo e(number_format($detail->qty * $detail->price * (1 - $detail->discount / 100))); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="d-flex">
                            <div>Total</div>
                            <div class="ms-auto mb-0 fw-bold">Rp<?php echo e(number_format($order->total)); ?></div>
                        </div>

                        <div class="d-flex">
                            <div>Payment</div>
                            <div class="ms-auto mb-0">Rp<?php echo e(number_format($order->payment)); ?></div>
                        </div>

                        <div class="d-flex">
                            <div>Kembalian</div>
                            <div class="ms-auto mb-0">Rp<?php echo e(number_format($order->payment - $order->total)); ?></div>
                        </div>
                    </div>
                </div>

                <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-dark no-print">Kembali</a>
                <button onclick="printPDF()" class="btn btn-primary no-print">Cetak PDF</button>
            </div>
        </div>
    </div>

    <style>
        @media print {
            body * {
                visibility: hidden; /* Sembunyikan semua elemen */
            }
            .card, .card * {
                visibility: visible; /* Tampilkan card dan semua elemennya */
            }
            .no-print {
                display: none; /* Sembunyikan elemen dengan kelas no-print */
            }
            .container {
                position: absolute;
                left: 50%;
                top: 0;
                transform: translateX(-50%);
                width: 100%;
                padding: 0;
                margin: 0;
            }
            .col-8 {
                width: 100%;
            }
            .card {
                border: none;
                box-shadow: none;
            }
            .card-body {
                padding: 1rem;
            }
            .d-flex {
                display: flex;
                justify-content: space-between;
            }
            .form-text {
                font-size: 1rem;
            }
        }
    </style>

    <script>
        function printPDF() {
            window.print();
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Vs Code\pibiti-2024\cashed\resources\views/order/show.blade.php ENDPATH**/ ?>