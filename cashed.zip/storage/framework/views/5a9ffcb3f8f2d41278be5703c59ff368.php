<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Dashboard Kasir <?php $__env->endSlot(); ?>

    <div class="container mt-4">
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body d-flex align-items-center gap-2 mx-auto">
                        <img src="<?php echo e(Storage::url('assets/87936963_9815552.jpg')); ?>" alt="logo-penjualan" class="bg-cover "
                            width="60px" height="60px" />
                        <div class="ms-3">
                            <h6 class="card-title">Total Pendapatan</h6>
                            <h5 class="card-text">Rp<?php echo e(number_format($totalSales)); ?></h5>
                            <!-- Mengubah total penjualan hari ini menjadi total semua penjualan -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body d-flex align-items-center gap-2 mx-auto">
                        <img src="<?php echo e(Storage::url('assets/11518988_4758003.jpg')); ?>" alt="logo-penjualan"
                            class="bg-cover " width="60px" height="60px" />
                        <div class="ms-3">
                            <h6 class="card-title">Jumlah Semua Transaksi</h6>
                            <h5 class="card-text"><?php echo e($transactionCount); ?> Transaksi</>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body d-flex align-items-center gap-2 mx-auto ">
                        <img src="<?php echo e(Storage::url('assets/7245734_3556180.jpg')); ?>" alt="logo-penjualan"
                            class="bg-cover d-flex align-items-center" width="60px" height="60px" />
                        <div class="ms-3">
                            <h6 class="card-title">Nilai Transaksi Rata-rata</h6>
                            <h5 class="card-text">Rp<?php echo e(number_format($averageTransactionValue)); ?></>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <h4 class="mt-2">Transaksi Terbaru</h4>
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="width: 15%;">No</th> <!-- Kolom untuk nomor transaksi -->
                            <th style="width: 25%;">Tanggal dan Waktu</th>
                            <!-- Kolom untuk tanggal dan waktu -->
                            <th style="width: 20%;">Customer</th>
                            <!-- Mengganti User dengan Customer -->
                            <th style="width: 25%;">Item Terjual</th> <!-- Kolom Item Terjual -->
                            <th style="width: 15%;">Total Jumlah</th> <!-- Kolom Total Jumlah -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Order #<?php echo e($transaction->id); ?></td>
                                <!-- Menampilkan nomor transaksi dari ID order -->
                                <td><?php echo e($transaction->created_at->format('d M Y H:i')); ?></td>
                                <!-- Menggabungkan tanggal dan waktu -->
                                <td><?php echo e($transaction->customer); ?></td>
                                <!-- Menampilkan nama customer -->
                                <td>
                                    <?php $__currentLoopData = $transaction->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($detail->qty); ?> <?php echo e($detail->product->name); ?><br>
                                        <!-- Menampilkan item terjual -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>Rp<?php echo e(number_format($transaction->total)); ?></td>
                                <!-- Menampilkan total jumlah -->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-6">
                <h4>Manajemen Penjualan</h4>
                <div class="row mt-3">
                    <div class="col-md-12">
                        <div class="row card-body d-flex">
                            <div class="col-6">
                                <div class="card">
                                    <div class="card-body d-flex justify-content-center align-items-center">
                                        <img src="<?php echo e(Storage::url('assets/stock.png')); ?>" alt="Pemberitahuan Stok"
                                            width="132em">
                                    </div>
                                </div>
                            </div>

                            <div class="col-6">
                                <a href="<?php echo e(route('products.index')); ?>" class="text-decoration-none">
                                    <!-- Tautan ke rute produk -->
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Pemberitahuan Stock</h5>
                                            <p class="card-text mt-3"><?php echo e($availableCount); ?> item tersedia.</p>
                                            <p class="card-text mt-3"><?php echo e($lowStockCount); ?> item hampir habis.</p>
                                            <p class="card-text mt-3"><?php echo e($outOfStockCount); ?> item habis.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mt-4">
                        <a href="<?php echo e(route('categories.index')); ?>" class="text-decoration-none">
                            <!-- Tautan ke rute kategori -->
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Jumlah Kategori</h5>
                                    <p class="card-text"><?php echo e($categoryCount); ?> kategori tersedia.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6 mt-4">
                        <a href="<?php echo e(route('products.index')); ?>" class="text-decoration-none">
                            <!-- Tautan ke rute produk -->
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Jumlah Produk</h5>
                                    <p class="card-text"><?php echo e($productCount); ?> produk tersedia.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <h4>Produk dengan Diskon Terbesar</h4>
                <div class="row mb-4">
                    <?php if($topDiscountedProduct): ?>
                        <div class="col-md-12 mt-2">
                            <div class="card">
                                <img src="<?php echo e(Storage::url($topDiscountedProduct->image)); ?>" class="card-img-top"
                                    alt="<?php echo e($topDiscountedProduct->name); ?>" style="object-fit: cover; height:12.6em;">
                                <div class="card-body d-flex">
                                    <div>
                                        <h5 class="card-title"><?php echo e($topDiscountedProduct->name); ?></h5>
                                        <p class="card-text">Diskon: <?php echo e($topDiscountedProduct->discount); ?>%</p>
                                    </div>
                                    <div class="ms-auto mt-auto">
                                        <a href="<?php echo e(route('orders.create.detail', $topDiscountedProduct->id)); ?>"
                                            class="btn btn-primary">Lihat Detail</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col-md-12 mt-2">
                            <div class="card d-flex justify-content-center align-items-center" style="height: 18.25em;">
                                <!-- Tambahkan kelas Flexbox -->
                                <div class="card-body d-flex justify-content-center align-items-center">
                                    <!-- Flexbox untuk card-body -->
                                    <h5 class="text-center">Tidak ada produk dengan diskon.</h5>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Vs Code\pibiti-2024\cashed\resources\views/dashboard.blade.php ENDPATH**/ ?>